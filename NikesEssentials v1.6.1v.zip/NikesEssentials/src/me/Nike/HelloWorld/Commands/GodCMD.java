package me.Nike.HelloWorld.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GodCMD implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p = (Player) sender;
		if (command.getName().equalsIgnoreCase("god")) 
		  if(!(sender instanceof Player)) {
			sender.sendMessage("Du musst ein Spieler sein!");
			return true;		  				
		  } else {
			  if (p.hasPermission("ne.god")) {
				  if (p.isInvulnerable()) {
					  p.setInvulnerable(false);
					  p.sendMessage(ChatColor.GRAY + "Der Godmodus wurde " + ChatColor.RED + "deaktiviert");
					  return true;
				  } else {
				  p.setInvulnerable(true);
				  p.sendMessage(ChatColor.GRAY + "Der Godmodus wurde " + ChatColor.GREEN + "aktiviert");
				  return true;
				  }
			  } else {
				  
				  
				  p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
				  return true;
			  }
			  
			  
			  
			  
			  
		  }
	

		return false;
	}
}
