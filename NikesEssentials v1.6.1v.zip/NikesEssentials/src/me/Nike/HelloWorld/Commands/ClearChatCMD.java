package me.Nike.HelloWorld.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;




public class ClearChatCMD implements CommandExecutor {
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p = (Player) sender;
		if (command.getName().equalsIgnoreCase("clearchat")) 
			  if(!(sender instanceof Player)) {
				  sender.sendMessage(ChatColor.RED + "[NE] Fehler: Du musst ein Spieler Sein!");
				  
				  
			  } else {
				  
				  if(p.hasPermission("ne.clearchat")) {
					  
					  if (args.length == 0 ) {
						  
						  for (Player all : Bukkit.getOnlinePlayers()) {
							  if(!all.hasPermission("ne.clearchat.bypass")) {
								  
								  Bukkit.broadcast(ChatColor.GRAY + "Der " + ChatColor.AQUA + "Chat " + ChatColor.GRAY + "wurde von " +ChatColor.GREEN + p.getDisplayName() + ChatColor.GRAY + " geleert.", "");
								  clear(all);
								  p.sendMessage(ChatColor.GRAY + "Der " + ChatColor.AQUA + "Chat " + ChatColor.GRAY + "wurde " + ChatColor.RED + "geleert");
								  return true;
							  } 
						  }						  
						  
					  }
					  
					  if(args.length == 1) {
						  Player t = Bukkit.getPlayer(args[0]);
						  
						  if(t == null) return true;
						  
						  clear(t);
						  p.sendMessage(ChatColor.GRAY + "Der " + ChatColor.GREEN + "Chat " + ChatColor.GRAY + "von " + ChatColor.DARK_PURPLE + t.getDisplayName() + ChatColor.GRAY + " wurde geleert");
						  t.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.AQUA + "Chat " + ChatColor.GRAY + "wurde von " +ChatColor.GREEN + p.getDisplayName() + ChatColor.GRAY + " geleert.");
						  
						  
						  return true;
					  }
					  
					  
					  
				  } else {
					  p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
					  return true;
				  }
				  
				  
				  
			  }
				  
		return false;
				  
			  }
	private void clear(Player p ) {
		for (int i = 0; i < 150; i++) {
			p.sendMessage("");
		}
	}
		
}
