package me.Nike.HelloWorld.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MainCMD implements CommandExecutor {
	
	
	
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (sender instanceof Player) {
			Player p = (Player) sender;
			
			if (cmd.getName().equalsIgnoreCase("ne")) {
				if (!p.hasPermission("ne.help")) {	
					
					p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
				
				
					return true;
				} else if (args.length == 0) {
						p.sendMessage(ChatColor.GRAY + "Zu wenig Argumente! " + ChatColor.YELLOW + "/ne help");
						return true;
					} else {
						p.sendMessage(ChatColor.GRAY + "Zu wenig Argumente! " + ChatColor.YELLOW + "/ne help");
						
						
					}
				
					    if (args[0].equalsIgnoreCase("help")) {
					
						p.sendMessage(ChatColor.DARK_GRAY + "----------------- " + ChatColor.DARK_PURPLE + "NikesEssentials v1.6 " + ChatColor.DARK_GRAY + "----------------- " );
						p.sendMessage(ChatColor.YELLOW + " /ne help " + ChatColor.GRAY + "Um eine Liste der Befehle zu erhalten");
						p.sendMessage(ChatColor.YELLOW + " /ec " + ChatColor.GRAY + "Um deine Enderkiste zu �ffnen!");
						p.sendMessage(ChatColor.YELLOW + " /kill " + ChatColor.GRAY + "Um einen Spieler zu t�ten!");
						p.sendMessage(ChatColor.YELLOW + " /gm 0-3 (Spieler) " + ChatColor.GRAY + "�ndert den Spielmodus");
						p.sendMessage(ChatColor.YELLOW + " /god " + ChatColor.GRAY + "Im Godmodus bist du Gott!");
						p.sendMessage(ChatColor.YELLOW + " /clearchat (Spieler) " + ChatColor.GRAY + "Leere den Chat von allen oder einem Spieler(n)");
						p.sendMessage(ChatColor.YELLOW + " /fly (Spieler) " + ChatColor.GRAY + "�ndert den Flugmodus");
						p.sendMessage(ChatColor.YELLOW + " /heal (Spieler) " + ChatColor.GRAY + "Tut dem Spieler gut :D");
						p.sendMessage(ChatColor.YELLOW + " /feed (Spieler) " + ChatColor.GRAY + "F�ttert arme Leute ;c");
						p.sendMessage(ChatColor.YELLOW + " /speed (Speed) (Spieler) " + ChatColor.GRAY + "Setzt die GEschwindigkeit");
						p.sendMessage(ChatColor.YELLOW + " /tpa (Spieler) " + ChatColor.GRAY + "Frag an ob man sich Teleportieren darf");
						p.sendMessage(ChatColor.YELLOW + " /tpa (Spieler) " + ChatColor.GRAY + "Nimmt die Teleportationsanfragean!");
						return true;

						}
					}
				}
			
		
		return false;
	}
}
	





	


