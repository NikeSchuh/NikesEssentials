package me.Nike.HelloWorld.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GMCMD implements CommandExecutor {
	
	
	
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p = (Player) sender;
		if (command.getName().equalsIgnoreCase("gm")) 
		  if(!(sender instanceof Player)) {
			sender.sendMessage(ChatColor.RED + "Du musst ein Spieler sein!");
			return true;
		  }
		if (!p.hasPermission("ne.gm")) {
			p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command auszuf�hren.");
			return true;
		} else {
			
		if (args.length == 0) {
			p.sendMessage(ChatColor.GRAY + "Benutzung: " + ChatColor.YELLOW + "/gm 0 - 3");
			return true;
		}
		if (args.length == 1) {
		 if (args[0].equalsIgnoreCase("1")) {
			 p.setGameMode(GameMode.CREATIVE);
			 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
			 return true;
			 
		 } else {
			 if (args[0].equalsIgnoreCase("0")) {
				 p.setGameMode(GameMode.SURVIVAL);
				 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
				 return true;
			 } else {
				 if (args[0].equalsIgnoreCase("2")) {
					 p.setGameMode(GameMode.ADVENTURE);
					 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
					 return true;
				 } else {
					 if (args[0].equalsIgnoreCase("3")) {
						 p.setGameMode(GameMode.SPECTATOR);
						 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
						 return true;
					 } else {
						 if (args[0].equalsIgnoreCase("creative")) {
							 p.setGameMode(GameMode.CREATIVE);
							 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
						     return true;
						 
						 } else {
							 if (args[0].equalsIgnoreCase("spectator")) {
								 p.setGameMode(GameMode.SPECTATOR);
								 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
								 return true;
							 } else {
								 if (args[0].equalsIgnoreCase("adventure")) {
									 p.setGameMode(GameMode.ADVENTURE);
									 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
									 return true;
									 
									 
								 } else {
									 if (args[0].equalsIgnoreCase("survival")) {
										 p.setGameMode(GameMode.SURVIVAL);
										 p.sendMessage(ChatColor.GRAY + "Dein " + ChatColor.GREEN + "Spielmodus " + ChatColor.GRAY + "wurde auf " + ChatColor.RED + p.getGameMode() + ChatColor.GRAY + " gesetzt");
										 return true;
									 }
								 }
								 
								 
								 
							 }
							 
						 }
						 
						 
						 
						 
					 }
					     
							 
							 
							 
							 
							 
							 
						  
					 p.sendMessage(ChatColor.GRAY + "Der Spielmodus " + ChatColor.RED + args[0] + ChatColor.GRAY + " konnte nicht " + ChatColor.BLUE + "gefunen " + ChatColor.GRAY + "werden" );
	                         return true;
							 
						 }
						 
						 
						 
					 }
					 
					 
					 
				 }
				 
				 
				 
			 } else if (args.length == 2) {
				 if (!p.hasPermission("ne.gm.other")) {
					 p.sendMessage(ChatColor.RED + "Keine Rechte um den Gamemode anderer Leute zu setzen");
					 return true;
				 } else {
				 Player target = Bukkit.getPlayer(args[1]);
				 if (target == null) {
					 p.sendMessage(ChatColor.RED + "Spieler ist nicht Online!");
					 return true;
				 } else {
				 
				 if (args[0].equalsIgnoreCase("0")) {
					 target.setGameMode(GameMode.SURVIVAL);
					 p.sendMessage(ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde in den Modus " + ChatColor.RED + target.getGameMode() + ChatColor.GRAY + " gesetzt.");
					 return true;
				 } else {
					 if (args[0].equalsIgnoreCase("1")) {
						 					 
						 target.setGameMode(GameMode.CREATIVE);
						 p.sendMessage(ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde in den Modus " + ChatColor.RED + target.getGameMode() + ChatColor.GRAY + " gesetzt.");
						 return true;
					 } else {
						 
						 if (args[0].equalsIgnoreCase("2")) {
		 					 
							 target.setGameMode(GameMode.ADVENTURE);
							 p.sendMessage(ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde in den Modus " + ChatColor.RED + target.getGameMode() + ChatColor.GRAY + " gesetzt.");
							 return true;
						 
						 } else {
							 if (args[0].equalsIgnoreCase("3")) {
			 					 
								 target.setGameMode(GameMode.SPECTATOR);
								 p.sendMessage(ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde in den Modus " + ChatColor.RED + target.getGameMode() + ChatColor.GRAY + " gesetzt.");
								 return true;
							 }
						 }
						 
					 }
				 }
				 
			}
				 
				 p.sendMessage(ChatColor.GRAY + "Der Spielmodus " + ChatColor.RED + args[0] + ChatColor.GRAY + " konnte nicht " + ChatColor.BLUE + "gefunen " + ChatColor.GRAY + "werden" );
				 return true;
				 
			 
			 
			 
		 } 
			 
		 
			 }
		 
		} 
			
		  
		return false;
	
	
	}
		
	
  }


