package me.Nike.HelloWorld.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KillCMD implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (sender instanceof Player) {
			Player p = (Player) sender;
			
			if (cmd.getName().equalsIgnoreCase("kill")) {
				if (!p.hasPermission("ne.kill.use")) {
					p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
					return true;
				}  else if (args.length == 0) {
						p.setHealth(0);
						p.sendMessage(ChatColor.GRAY + "Du wirst " + ChatColor.RED + "get�tet");
					}
					else if (args.length == 1) {
						
						
						
						if (!p.hasPermission("ne.kill.other")) {
							p.sendMessage(ChatColor.RED + "Du kannst keine anderen Leute t�ten!");
							return true;
							
						}
						Player p1 = Bukkit.getPlayer(args[0]);
						
						if (p1 != null && p1.isOnline()) {
							p1.setHealth(0);
							p1.sendMessage(ChatColor.GREEN + p.getDisplayName() + ChatColor.GRAY + " hat dich get�tet");
							p.sendMessage(ChatColor.GRAY +"Du hast "+ ChatColor.AQUA +  p1.getDisplayName() + ChatColor.GRAY + " per Kommando" + ChatColor.RED + " get�tet");									
						} else {
							p1.sendMessage("Spieler ist nicht online!"  + p1.getDisplayName());
							return false;
						}
					}
				}
			}
		
		return true;
	}
}
	
	    

		
	
	
		
	
	
	
	
