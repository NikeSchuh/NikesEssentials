package me.Nike.HelloWorld.Commands;

import java.util.ArrayList;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EnderchestCMD implements CommandExecutor {
	
	public static ArrayList<UUID> enderchest = new ArrayList<UUID>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p1 = (Player) sender;
		if (command.getName().equalsIgnoreCase("chestopen")) 
		  if(!(sender instanceof Player)) {
			sender.sendMessage("Du musst ein Spieler sein!");
			return true;		  				
		  
		}
		
		
		
		if(!p1.hasPermission("ne.enderchest.open")) {
			p1.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
			return true;
		}
		
		if(args.length == 0) {
			p1.openInventory(p1.getEnderChest());
			p1.sendMessage(ChatColor.GRAY + "Deine " + ChatColor.GREEN + "Enderchest " + ChatColor.GRAY + "wird ge�ffnet" );
	}
		else if(args.length == 1) {
			if(!p1.hasPermission("ne.enderchest.open.other")) {
				p1.sendMessage(ChatColor.RED + "Du kannst nur deine Endertruhe �ffnen!");
				return true;
			
			}
			Player target = Bukkit.getPlayer(args[0]);
			if(target == null) {
				p1.sendMessage(ChatColor.DARK_RED + "Spieler wurde nicht gefunden oder ist nicht Online");
				return true;
			}
			p1.openInventory(target.getEnderChest());
			p1.sendMessage("�7 Du schaust nun in die Enderchest von "+ ChatColor.GREEN + target.getName());
			enderchest.contains(p1.getUniqueId());
		} else {
			p1.sendMessage("�7 Verwendung: $e/" + label + "<Spieler>");
					}
		return true;
		}
	
	
		
	}
		
	
			
		
		
		
		
