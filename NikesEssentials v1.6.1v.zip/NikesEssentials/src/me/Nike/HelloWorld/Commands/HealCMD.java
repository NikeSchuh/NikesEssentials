package me.Nike.HelloWorld.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HealCMD implements CommandExecutor {
	
	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p = (Player) sender;
		if (command.getName().equalsIgnoreCase("heal")) 
		  if(!(sender instanceof Player)) {
			sender.sendMessage("Du musst ein Spieler sein!");
			return true;
		  } else {
			  if (!p.hasPermission("ne.heal")) {
				  
				  p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
			      return true;
			      
				  
			  } else {
				  if (args.length == 0 ) {
					 p.sendMessage(ChatColor.GRAY + "Du wurdest " + ChatColor.GREEN + "geheilt");
					  p.setHealth(p.getMaxHealth());
					  return true;
					  
				  } else {
					  if (args.length == 1 ) {
						  if (!p.hasPermission("ne.heal.other")) {
							  
							  p.sendMessage(ChatColor.RED + "Keine Rechte um andere Leute zu heilen");
							  
						  } else {
						  Player target = Bukkit.getPlayer(args[0]);
							if(target == null) {
								p.sendMessage(ChatColor.DARK_RED + "Spieler wurde nicht gefunden oder ist nicht Online");
								return true;
							} else {
								p.sendMessage(ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde " + ChatColor.DARK_PURPLE + "geheilt" );
								target.sendMessage(ChatColor.GRAY + "Du wurdest " + ChatColor.GREEN + "geheilt");
								target.setHealth(p.getMaxHealth());
								return true;
							}
								
						  }
					  }
				  }
			  }
		  }
		return false;
	}
}
