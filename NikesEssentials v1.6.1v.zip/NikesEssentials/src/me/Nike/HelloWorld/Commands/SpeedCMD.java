package me.Nike.HelloWorld.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpeedCMD implements CommandExecutor {
	
	
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p = (Player) sender;
		if (command.getName().equalsIgnoreCase("speed")) 
		  if(!(sender instanceof Player)) {
			sender.sendMessage("Du musst ein Spieler sein!");
			return true;
		  } else {
			  if (!p.hasPermission("ne.speed")) {
				  p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
				  return true;
			  } else {
				  if (args.length == 0) {
					  p.sendMessage(ChatColor.RED + "Falsche Benutzung! /speed 1 - 10");
					  return true;
					  
				  } else {
					  if (args.length == 1) {
						 
						  float speed = Float.valueOf(args[0]) / 10;
								                                                  
						  if (p.isFlying()) {
							  p.setFlySpeed(speed);
							  p.sendMessage(ChatColor.GRAY + "Deine " + ChatColor.RED + "Fluggeschwindigkeit " + ChatColor.GRAY + "wurde auf " + ChatColor.GREEN + p.getFlySpeed() + ChatColor.GRAY + " gesetzt");
							  return true;
							  
						  } else {
							  float walkspeed = Float.valueOf(args[0]) / 10;				
							  p.setWalkSpeed(walkspeed);
							  p.sendMessage(ChatColor.GRAY + "Deine " + ChatColor.RED + "Laufgeschwindigkeit " + ChatColor.GRAY + "wurde auf " + ChatColor.GREEN + p.getWalkSpeed() + ChatColor.GRAY + " gesetzt");
							  return true;
							  
						  }
						  
						  
						  
						  
					  } else {
						  if (args.length == 2 ) {
							  if (!p.hasPermission("ne.speed.other")) {
								  p.sendMessage(ChatColor.RED + "Keine Rechte um anderen Leuten die Geschwindigkeit zu setzen!");
								  return true;
							  } else {
							  Player target = Bukkit.getPlayer(args[1]);
							  if (target.isFlying()) {
								  float fly = Float.valueOf(args[0]) / 10;
								  target.setFlySpeed(fly);
								  target.sendMessage(ChatColor.GRAY + "Deine " + ChatColor.RED + "Fluggeschwindigkeit " + ChatColor.GRAY + "wurde auf " + ChatColor.GREEN + target.getFlySpeed() + ChatColor.GRAY + " gesetzt");
								  p.sendMessage(ChatColor.GRAY + "Die " +  ChatColor.RED + "Fluggeschwindigkeit" + ChatColor.GRAY + "von " + ChatColor.DARK_PURPLE + target.getDisplayName() + ChatColor.GRAY + " wurde auf " + ChatColor.GREEN + target.getFlySpeed());
								  return true;
							  } else {
								  float walk = Float.valueOf(args[0]) / 10;
								  target.setWalkSpeed(walk);
								  target.sendMessage(ChatColor.GRAY + "Deine " + ChatColor.RED + "Laufgeschwindigkeit " + ChatColor.GRAY + "wurde auf " + ChatColor.GREEN + target.getWalkSpeed() + ChatColor.GRAY + " gesetzt");
								  p.sendMessage(ChatColor.GRAY + "Die " +  ChatColor.RED + "Laufgeschwindigkeit" + ChatColor.GRAY + "von " + ChatColor.DARK_PURPLE + target.getDisplayName() + ChatColor.GRAY + " wurde auf " + ChatColor.GREEN + target.getWalkSpeed());
								  return true;
							  }
							  }
						  }
					  }
				  }
				  p.sendMessage("�cEin Unbekannter Fehler ist aufgetreten");
				  return true;
				  
			  }
		  }
		return false;
		
	}

}
