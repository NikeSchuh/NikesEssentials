package me.Nike.HelloWorld.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCMD implements CommandExecutor {
	
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player p = (Player) sender;
		if (command.getName().equalsIgnoreCase("fly"))  
		  if(!(sender instanceof Player)) {
			sender.sendMessage("Du musst ein Spieler sein!");
			return true;
		  
			
	
		  } else {
			  
			 if (!p.hasPermission("ne.fly")) {
				 p.sendMessage(ChatColor.RED + "Du musst ein Administrator oder h�her sein um diesen Command ausf�hren zu k�nnen.");
				 return true;
				 
				 
				 
				 
			 } else {
				 if (args.length == 0 ) {
					 if (p.isFlying()) {
						 p.setAllowFlight(false);
						 p.setFlying(false);
						 p.sendMessage(ChatColor.GRAY + "Der " + ChatColor.DARK_PURPLE + "Flugmodus " + ChatColor.GRAY + "wurde " + ChatColor.RED + "deaktiviert");
						 return true;
						 
					 } else {
						 if (!p.isFlying()) {
							 p.setAllowFlight(true);
							 p.setFlying(true);
							 p.sendMessage(ChatColor.GRAY + "Der " + ChatColor.DARK_PURPLE + "Flugmodus " + ChatColor.GRAY + "wurde " + ChatColor.GREEN + "aktiviert");
							 return true;
						 } 
					}
				
		
			
					 
				 
				
			 } else {
				 if (args.length == 1 ) {
					 if (!p.hasPermission("ne.fly.other")) {
						 p.sendMessage(ChatColor.RED + "Keine Rechte um anderen den Flugmodus zu bestimmen!");
						 return true;
					 } else {	 
					 Player target = Bukkit.getPlayer(args[0]);							
						if(target == null) {
							p.sendMessage(ChatColor.RED + "Spieler wurde nicht gefunden oder ist nicht Online!");
							return true;
						} else {	
							if (target.isFlying()) {
								target.setAllowFlight(false);
								target.setFlying(false);
								 target.sendMessage(ChatColor.GRAY + "Der " + ChatColor.DARK_PURPLE + "Flugmodus " + ChatColor.GRAY + "wurde f�r dich " + ChatColor.RED + "deaktiviert");
								 p.sendMessage(ChatColor.GRAY + "Der " + ChatColor.DARK_PURPLE + "Flugmodus " + ChatColor.GRAY + "f�r " + ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde " + ChatColor.RED + "deaktiviert");
								 return true;									
							} else {	
								if (!target.isFlying()) {
									target.setAllowFlight(true);
									target.setFlying(true);
									 target.sendMessage(ChatColor.GRAY + "Der " + ChatColor.DARK_PURPLE + "Flugmodus " + ChatColor.GRAY + "wurde f�r dich " + ChatColor.GREEN + "aktiviert");
									 p.sendMessage(ChatColor.GRAY + "Der " + ChatColor.DARK_PURPLE + "Flugmodus " + ChatColor.GRAY + "f�r " + ChatColor.GREEN + target.getDisplayName() + ChatColor.GRAY + " wurde " + ChatColor.GREEN + "aktiviert");
									 return true;
								}
							}
						}
					 }		
				 }
			 }
			 }
		  }
		
		  
		return false;
}
}