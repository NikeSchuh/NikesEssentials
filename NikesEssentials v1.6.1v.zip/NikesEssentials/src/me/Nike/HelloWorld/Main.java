package me.Nike.HelloWorld;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

import me.Nike.HelloWorld.Commands.ClearChatCMD;
import me.Nike.HelloWorld.Commands.EnderchestCMD;
import me.Nike.HelloWorld.Commands.FeedCMD;
import me.Nike.HelloWorld.Commands.FlyCMD;
import me.Nike.HelloWorld.Commands.GMCMD;
import me.Nike.HelloWorld.Commands.GodCMD;
import me.Nike.HelloWorld.Commands.HealCMD;
import me.Nike.HelloWorld.Commands.KillCMD;
import me.Nike.HelloWorld.Commands.MainCMD;
import me.Nike.HelloWorld.Commands.SpeedCMD;
import me.Nike.HelloWorld.Commands.TpaCMD;


public class Main extends JavaPlugin{
	
	

	
	@Override
	public void onEnable() {
		
 
		 Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA + "[NikesEssentials] Starte Plugin ...");
		
		//Commands		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA + "[NikesEssentials] Inizialisiere Kommandos ...");
		
		
		
		getCommand("chestopen").setExecutor(new EnderchestCMD());
		getCommand("kill").setExecutor(new KillCMD());
		getCommand("ne").setExecutor(new MainCMD());
		getCommand("gm").setExecutor(new GMCMD());
		getCommand("god").setExecutor(new GodCMD());
		getCommand("clearchat").setExecutor(new ClearChatCMD());
		getCommand("fly").setExecutor(new FlyCMD());
		getCommand("heal").setExecutor(new HealCMD());
		getCommand("feed").setExecutor(new FeedCMD());
		getCommand("speed").setExecutor(new SpeedCMD());
		getCommand("tpa").setExecutor(new TpaCMD());
		getCommand("tpaccept").setExecutor(new TpaCMD());
		
		
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA + "[NikesEssentials] Kommandos erfolgteich Inizialisiert");
		
		
					
		Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "[NikesEssentials] NikesEssentials wurde erfolgreich gestartet!");
	
	}
	
	@Override
	public void onDisable() {
		
		Bukkit.getConsoleSender().sendMessage(ChatColor.YELLOW + "[NikesEssentials] Entlade Komponenten ...");
		
		
		
		
		Bukkit.getConsoleSender().sendMessage(ChatColor.YELLOW + "[NikesEssentials] Deaktiviere Plugin ...");
		
		
	}
		
	}



	
	
	


		
	


			
